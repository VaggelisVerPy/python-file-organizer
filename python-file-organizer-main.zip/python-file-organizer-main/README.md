Python File Organizer

This is a Python automation script that organizes files inside a folder into category subfolders such as Images, Documents, Audio, Video, Archives, Code, and Others based on file extensions.
It scans the entire folder recursively and safely moves files while avoiding name conflicts.

-FEATURES-

• Automatically organizes files by category
• Supports recursive folder scanning
• Handles duplicate filenames safely
• Supports hidden files and symbolic links
• Dry-run mode for safe testing
• Custom root folder path
• Clean project summary with statistics

-HOW IT WORKS-

1. You set the root folder path inside the script
2. The script scans all files and subfolders
3. Each file is moved into the correct category folder
4. If a file with the same name exists, it automatically creates a unique name
5. At the end, a summary is printed with total processed files and errors

-REQUIREMENTS-

Python 3.10 or newer
No external libraries required

-USAGE-

Run the script and it will organize all files inside the selected folder automatically

-PROJECT STATUS-

Completed!
Future improvements may include GUI interface and real-time monitoring.

-AUTHOR-

Developed by Vaggelis Verouchis
Junior Python Developer